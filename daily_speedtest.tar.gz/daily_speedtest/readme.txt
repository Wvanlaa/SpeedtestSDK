Application Name
================
daily_speedtest


Application Version
===================
0.4


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
daily_speedtest - will run a speedtest at 11:00am daily and send an alert with results.

You can change the testing hour in the hotspot TOS text box - just enter the hour in 24hr format (17 = 5:00pm).

06:51:18 PM INFO daily_speedtest Daily speedtest scheduled for 11:00 -- Running now...
06:51:41 PM INFO daily_speedtest 51.48Mbps Down / 10.61Mbps Up / 105ms latency


Expected Output
===============
Speedtest results in alert

