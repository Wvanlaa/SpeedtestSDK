#!/bin/bash
cppython daily_speedtest.py